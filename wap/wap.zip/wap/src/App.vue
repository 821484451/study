<template>
  <div id="app">
    <router-view/>
    <main-loading/>
    <main-tip/>
    <main-qrcode/>
  </div>
</template>

<script>
import loading from './components/public/loading.vue'
import tip from './components/public/tip.vue'
import qrcode from './components/public/qrcode.vue'
export default {
  name: 'App',
  components: {
    'main-loading': loading,
    'main-tip': tip,
    'main-qrcode': qrcode
  }
}
</script>

<style lang="scss">
@import './assets/styles/base.scss';
</style>
