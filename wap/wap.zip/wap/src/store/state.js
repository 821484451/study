export default {
  isLoading: false,
  tip: false,
  msg: '',
  qrCodeStatus: false,
  searchFlag: true,
  selectNum: 0,
  popStatus: false,
  addText: '',
  popAddStatus: false,
  incomeTabFlag: true,
  searchUrl: '',
  loginStatus: false,
  home: {
    accountMoney: '',
    ptbMoney: '',
    frozenMoney: ''
  },
  homeWater: {
    monthWater: '',
    todayWater: '',
    monthDetail: [],
    timeList: []
  },
  echarts: {
    commonTimeList: [],
    detail: []
  }
}
