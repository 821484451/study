// 获取loading状态
export const loadingStatus = state => state.isLoading
// 提示框
export const tipMsg = state => state.msg
export const tipStatus = state => state.tip
// 二维码
export const qrCodeStatus = state => state.qrCodeStatus
// 搜索
export const searchFlag = state => state.searchFlag
export const selectNum = state => state.selectNum
// 弹窗
export const popStatus = state => state.popStatus
export const addText = state => state.addText
export const popAddStatus = state => state.popAddStatus
export const incomeTabFlag = state => state.incomeTabFlag
// 搜索接口
export const searchUrl = state => state.searchUrl
export const loginStatus = state => state.loginStatus
// 首页初始化数据
export const accountMoney = state => state.home.accountMoney
export const ptbMoney = state => state.home.ptbMoney
export const frozenMoney = state => state.home.frozenMoney
export const monthWater = state => state.homeWater.monthWater
export const todayWater = state => state.homeWater.todayWater
export const timeList = state => state.homeWater.timeList
export const monthDetail = state => state.homeWater.monthDetail
// echarts
export const commonTimeList = state => state.echarts.commonTimeList
export const detail = state => state.echarts.detail
