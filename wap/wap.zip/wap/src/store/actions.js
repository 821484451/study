import * as api from '../api'
// 普通登录
export const userLogin = ({ commit }, data) => {
  api.userLogin(data, res => {
    if (res.msg === 'success') {
      commit('UPDATE_LOGIN_STATUS', {loginStatus: true})
      window.localStorage.setItem('userId', res.data.user_id)
    } else {
      commit('UPDATE_LOGIN_STATUS', {loginStatus: false})
    }
  }, error => {
    console.info(error)
  })
}
export const homeInit = ({ commit }, data) => {
  api.homeInit(data, res => {
    if (res.msg === 'success') {
      commit('INIT_HOME_DATA', {accountMoney: res.data.account_money, ptbMoney: res.data.ptb_money, frozenMoney: res.data.frozen_money})
    } else {
      console.log(res.msg)
    }
  }, error => {
    console.info(error)
  })
}
export const monthWater = ({ commit }, data) => {
  api.monthWater(data, res => {
    if (res.msg === 'success') {
      commit('GET_MONTH_WATER', {
        monthWater: res.data.month_water,
        todayWater: res.data.today_water,
        monthDetail: res.data.month_water_detail,
        timeList: res.data.time_list
      })
      commit('UPDATE_ECHARTS_DATA', {commonTimeList: res.data.time_list, detail: res.data.month_water_detail})
    } else {
      console.log(res.msg)
    }
  }, error => {
    console.info(error)
  })
}
