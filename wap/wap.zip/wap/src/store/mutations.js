import Vue from 'vue'
const mutations = {
  // 改变loading状态
  UPDATE_LOADING_STATUS (state, payload) {
    state.isLoading = payload.isLoading
  },
  UPDATE_TIP_STATUS (state, content) {
    state.tip = content.tip
    state.msg = content.msg
    setTimeout(function () {
      state.tip = false
    }, 1000)
  },
  UPDATE_QRCODE_STATUS (state, payload) {
    state.qrCodeStatus = payload.qrCodeStatus
  },
  UPDATE_SEARCH_STATUS (state, payload) {
    state.searchFlag = payload.searchFlag
  },
  UPDATE_SELECT_NUM (state, payload) {
    state.selectNum = payload.num
  },
  UPDATE_POP_STATUS (state, payload) {
    state.popStatus = payload.popStatus
  },
  UPDATE_ADD_STATUS (state, content) {
    state.popAddStatus = content.popAddStatus
    state.addText = content.addText
  },
  UPDATE_INCOME_FLAG (state, content) {
    state.incomeTabFlag = content.incomeTabFlag
  },
  UPDATE_SEARCH_URL (state, content) {
    state.searchUrl = content.searchUrl
  },
  UPDATE_LOGIN_STATUS (state, content) {
    state.loginStatus = content.loginStatus
  },
  INIT_HOME_DATA (state, content) {
    Vue.set(state, 'home', {
      accountMoney: content.accountMoney,
      ptbMoney: content.ptbMoney,
      frozenMoney: content.frozenMoney
    })
  },
  GET_MONTH_WATER (state, content) {
    Vue.set(state, 'homeWater', {
      monthWater: content.monthWater,
      todayWater: content.todayWater,
      timeList: content.timeList,
      monthDetail: content.monthDetail
    })
  },
  UPDATE_ECHARTS_DATA (state, content) {
    Vue.set(state, 'echarts', content)
  }

}
export default mutations
