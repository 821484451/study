<template>

  <div class="home">
    <Header :left="left" :right="right" :text="text" :rightText="rightText" :toUrl="toUrl" @popAC="popAC"/>
    <div class="main">
      <Search/>
      <div class="searchContent">
        <ul class="searchContent_ul">
          <li class="searchContent_ul__li">
            <div class="channelName">渠道01</div>
            <div class="channelAccount">
              <div>渠道账号:<span>131313313</span></div>
              <div>手机号码:<span>131313313</span></div>
            </div>
            <div class="channelTime">2018-03-06 15:23</div>
          </li>
          <li class="searchContent_ul__li">
            <div class="channelName">渠道01</div>
            <div class="channelAccount">
              <div>渠道账号:<span>131313313</span></div>
              <div>手机号码:<span>131313313</span></div>
            </div>
            <div class="channelTime">2018-03-06 15:23</div>
          </li>
          <li class="searchContent_ul__li">
            <div class="channelName">渠道01</div>
            <div class="channelAccount">
              <div>渠道账号:<span>131313313</span></div>
              <div>手机号码:<span>131313313</span></div>
            </div>
            <div class="channelTime">2018-03-06 15:23</div>
          </li>
        </ul>
      </div>
    </div>
    <div class="addChannel" v-if="popAddChannel" @click.prevent>
      <div class="addChannelBox">
        <h4>添加下级渠道</h4>
        <div class="inputList">
          <div class="inputBox">
            <span class="inputBox_name">渠道名称：</span>
            <input type="text" class="inputBox_input">
          </div>
          <div class="inputBox">
            <span class="inputBox_name">渠道账号：</span>
            <input type="text" class="inputBox_input">
          </div>
          <div class="inputBox">
            <span class="inputBox_name">登陆密码：</span>
            <input type="text" class="inputBox_input">
          </div>
        </div>
        <div class="addChannelBox_footer">
          <a href="javascript:;" @click.stop="popAC()">取消</a>
          <a href="javascript:;" @click.stop="popAC()">确定</a>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import header from '../public/header.vue'
import search from '../public/search.vue'
export default {
  components: {
    'Header': header,
    'Search': search

  },
  data () {
    return {
      left: 1,
      right: 1,
      text: '渠道列表',
      rightText: '添加',
      toUrl: '',
      popAddChannel: false

    }
  },
  methods: {
    popAC () {
      this.popAddChannel = !this.popAddChannel
    }

  }
}
</script>

<style lang="scss" scoped>
.home{
  background-color: #f5f6ff;
}

.searchContent{
  background-color: #fff;
  &_ul{
    padding: 0 0.3rem;
    &__li{
      padding-top: 0.3rem;
      padding-bottom: 0.3rem;
      border-bottom: 1px solid #EEEEEE;
      .channelName{
        font-size: 0.3rem;
        color: #000;
      }
      .channelAccount{
        padding-top: 0.21rem;
        display: flex;
        div{
          flex: 1;
          font-size: 0.24rem;
          span{
            color: #E41515;
          }
        }
      }
      .channelTime{
        padding-top: 0.21rem;
        font-size: 0.24rem;
        color: #7C7C7C;
      }
    }
  }
}
.addChannel{
  position: absolute;
  width:100%;
  height: 100%;
  background-color: rgba(0,0,0,0.5);
  left: 0;
  top: 0;
  .addChannelBox{
    width: 5.8rem;
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%,-50%);
    background-color: #fff;
    border-radius: 0.07rem;
    font-size: 0.3rem;
    color: #333;
    h4{
      line-height: 1rem;
      text-align: center;
    }
    &_footer{
      height: 1rem;
      line-height: 1rem;
      text-align:center;
      display: flex;
      margin-top: 0.2rem;
      a{
        flex: 1;
      }
      a:nth-child(1){
        color: #777;
        border-top: 1px solid #D2D3D5;
        border-right: 1px solid #D2D3D5;
      }
      a:nth-child(2){
        color:#409FFF;
        border-top: 1px solid #D2D3D5;
      }
    }
  }

}
.inputList{
  padding: 0 0.3rem;
}
.inputBox{
  height: 0.75rem;
  line-height: 0.75rem;
  display: flex;
  border: 1px solid #EEEEEE;
  margin-bottom: 0.15rem;
  &_name{
    width: 40%;
    height: 100%;
    text-align: center;
    line-height: 0.75rem;
    font-size: 0.26rem;
  }
  &_input{
    height: 100%;
    border: none;
    width: 60%;
  }
}

</style>
