<template>
  <div class="home">
    <Header :left="left" :right="right" :text="text" :rightText="rightText" :toUrl="toUrl"/>
    <div class="main">
      <Search :time="time" :orderNum="orderNum"  :searchBox="searchBox" :playerChannel="playerChannel"/>
      <div class="chargeList">
        <div class="chargeList_head">
          <div class="chargeList_head__div1">
            <p>汇总</p>
            <p>发放数量：2441&nbsp;&nbsp;&nbsp;&nbsp;支付金额：￥21313</p>
          </div>
          <div class="chargeList_head__div2">
            <img src="../../assets/images/huosdk_tg_rili.png" alt="">
          </div>
        </div>
        <ul class="chargeList_list">
          <li class="chargeList_list__li list" @click="toDetail('/ptbissuedetail/1')">
            <div class="list_div1">
              <p class="list_div1__p1">12313132</p>
              <p class="list_div1__p2">2018-06-01 15:30</p>
            </div>
            <div class="list_div2">
              <p class="list_div2__p1">-20</p>
              <p class="list_div2__p2">发币数量</p>
              <i></i>
            </div>
          </li>
          <li class="chargeList_list__li list" @click="toDetail('/ptbissuedetail/0')">
            <div class="list_div1">
              <p class="list_div1__p1">玩家001</p>
              <p class="list_div1__p2">2018-06-01 15:30</p>
            </div>
            <div class="list_div2">
              <p class="list_div2__p1">-20</p>
              <p class="list_div2__p2">发币数量</p>
              <i></i>
            </div>
          </li>
          <li class="chargeList_list__li list" @click="toDetail('/ptbissuedetail/0')">
            <div class="list_div1">
              <p class="list_div1__p1">玩家001</p>
              <p class="list_div1__p2">2018-06-01 15:30</p>
            </div>
            <div class="list_div2">
              <p class="list_div2__p1">-20</p>
              <p class="list_div2__p2">发币数量</p>
              <i></i>
            </div>
          </li>
        </ul>
      </div>
    </div>
  </div>

</template>

<script>
import header from '../public/header.vue'
import search from '../public/search.vue'
export default {
  components: {
    'Header': header,
    'Search': search
  },
  data () {
    return {
      left: 1,
      right: 0,
      text: '平台币发放记录',
      rightText: '',
      toUrl: '',
      time: true,
      orderNum: true,
      playerChannel: true,
      searchBox: false
    }
  },
  created () {

  },
  methods: {
    toDetail (url) {
      this.$router.push({path: url})
    }
  }
}
</script>

<style lang="scss" scoped>
.chargeList_list{
  padding: 0 0.3rem;
  background-color: #fff;
  &__li{
    display: flex;
    justify-content: space-between;
  }
}
.list{
  height: 1.44rem;
  border-bottom: 1px solid #EEEEEE;
  div{
    display: flex;
    flex-direction: column;
    justify-content: center;
  }
  &_div1{
    &__p1{
      font-size: 0.3rem;
      color: #000;
      span{
        color: #E41515;
        font-size: 0.24rem;
      }
    }
    &__p2{
      font-size: 0.24rem;
      color: #7C7C7C;
      padding-top: 0.23rem;
    }
  }
  &_div2{
    position: relative;
    &__p1{
      font-size: 0.56rem;
      color: #FF3D59;
      font-weight: bold;
    }
    &__p2{
      font-size: 0.24rem;
      color: #888;
    }
    i{
      width: 1px;
      height: 0.5rem;
      background-color: #EEE;
      position: absolute;
      left: -0.5rem;
      top: 50%;
      margin-top: -0.25rem;

    }
  }

}
.chargeList_head{
  padding: 0 0.3rem;
  display: flex;
  background-color: #F5F5F9;
  &__div1{
    flex: 1;
    p:nth-child(1){
      font-size: 0.28rem;
      color: #333;
      line-height: 0.5rem;
    }
    p:nth-child(2){
      font-size: 0.24rem;
      line-height: 0.5rem;
      color: #999;
    }
    p:nth-child(3){
      font-size: 0.24rem;
      line-height: 0.5rem;
      color: #999;
    }
  }
  &__div2{
    width: 0.45rem;
    position: relative;
    img{
      width: 0.35rem;
      height: 0.34rem;
      position: absolute;
      left: 50%;
      top: 50%;
      transform: translate(-50%,-50%);
    }
  }
}
</style>
