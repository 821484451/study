<template>
  <div class="home">
    <Header :left="left" :right="right" :text="text" :rightText="rightText" :toUrl="toUrl" :leftUrl="leftUrl" />
    <div class="gameTab">
      <div class="gameTab_item" @click="select()"><router-link to="/incomerecord/playerincomerecord">玩家收益记录<i v-if="incomeTabFlag"></i></router-link></div>
      <div class="gameTab_item" @click="select()"><router-link to="/incomerecord/childincomerecord">子渠道收益记录<i v-if="! incomeTabFlag"></i></router-link></div>
    </div>
    <div class="main">
      <Search :channelStatus="channelStatus" :channelList="channelList" :time="time" :playerAccount="playerAccount" :orderNum="orderNum" :searchBox="searchBox"/>
      <div class="chargeList">
        <div class="chargeList">
          <div class="chargeList_head">
            <div class="chargeList_head__div1">
              <p>汇总</p>
              <p>金额： ￥1800&nbsp;&nbsp;&nbsp;实付金额：￥52441</p>
              <p> 渠道收益：￥565677</p>
            </div>
            <div class="chargeList_head__div2">
              <img src="../../assets/images/huosdk_tg_rili.png" alt="">
            </div>
          </div>
          <router-view/>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import header from '../public/header.vue'
import search from '../public/search.vue'
import { mapGetters } from 'vuex'
import store from '../../store'
export default {
  components: {
    'Header': header,
    'Search': search
  },
  data () {
    return {
      left: 1,
      right: 0,
      text: '收益记录',
      rightText: '',
      toUrl: '',
      leftUrl: '/financial/cash',
      channelStatus: true,
      channelList: ['渠道1', '渠道2', '渠道3', '渠道4', '渠道5', '渠道6', '渠道7', '渠道7'],
      time: true,
      playerAccount: true,
      orderNum: true,
      searchBox: false
    }
  },
  created () {

  },
  computed: {
    ...mapGetters([
      'incomeTabFlag'
    ])
  },
  methods: {
    select () {
      if (this.incomeTabFlag) {
        store.commit('UPDATE_INCOME_FLAG', { 'incomeTabFlag': false })
      } else {
        store.commit('UPDATE_INCOME_FLAG', { 'incomeTabFlag': true })
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.home{
  background: url('../../assets/images/huosdk_tg_bg_001.png') no-repeat top;
  background-size: 100% auto;
  background-color: #f5f6ff;
  padding-bottom: 1.06rem;
  .header{
    background: none;
  }
}
.chargeList_head{
  padding: 0 0.3rem;
  display: flex;
  background-color: #F5F5F9;
  &__div1{
    flex: 1;
    p:nth-child(1){
      font-size: 0.28rem;
      color: #333;
      line-height: 0.5rem;
    }
    p:nth-child(2){
      font-size: 0.24rem;
      line-height: 0.5rem;
      color: #999;
    }
    p:nth-child(3){
      font-size: 0.24rem;
      line-height: 0.5rem;
      color: #999;
    }
  }
  &__div2{
    width: 0.45rem;
    position: relative;
    img{
      width: 0.35rem;
      height: 0.34rem;
      position: absolute;
      left: 50%;
      top: 50%;
      transform: translate(-50%,-50%);
    }
  }
}
.gameTab{
    height: 1rem;
    display: flex;
    &_item{
      flex: 1;
      text-align: center;
      line-height: 1rem;
      font-size: 0.3rem;
      color: #fff;
      position: relative;
      a{
        color: #fff;
      }
      i{
        position: absolute;
        left: 50%;
        transform: translateX(-50%);
        bottom: 0.05rem;
        display: inline-block;
        width: 1.4rem;
        height: 0.04rem;
        background-color: #fff;
      }
    }
  }

</style>
