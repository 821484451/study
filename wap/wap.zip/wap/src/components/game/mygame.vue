<template>
  <div class="myGame">
    <ul class="myGame_ul">
      <li class="myGame_ul__li">
        <div class="gameImg"><img src="../../assets/images/1.png" alt=""></div>
        <div class="gameDetail">
          <p class="gameDetail_p1">三届毒霸&nbsp;&nbsp;<img src="../../assets/images/huosdk_tg_android.png" ></p>
          <p class="gameDetail_p2">游戏ID：123123</p>
          <p class="gameDetail_p3"><span class="discounts">待出包</span></p>
        </div>
        <div class="gameBtn"><a href="javascript:;" @click="popTip('分包成功')">生成包</a></div>
      </li>
      <li class="proportion">
        <div>
          <p>发币折扣：<span>0.5</span></p>
          <p>返利比例：<span>20%</span></p>
          <p></p>
        </div>
        <div>
          <p>下级发币：<span>0.5</span></p>
          <p>下级返利：<span>20%</span></p>
          <p>优惠类型：<span>返利</span></p>
        </div>
      </li>
    </ul>
    <ul class="myGame_ul">
      <li class="myGame_ul__li">
        <div class="gameImg"><img src="../../assets/images/2.png" alt=""></div>
        <div class="gameDetail">
          <p class="gameDetail_p1">三届毒霸&nbsp;&nbsp;<img src="../../assets/images/huosdk_tg_android.png" ></p>
          <p class="gameDetail_p2">游戏ID：123123</p>
          <p class="gameDetail_p3"><span class="discounts">待出包</span></p>
        </div>
        <div class="gameBtn"><a href="javascript:;" @click="popTip('分包成功')">生成包</a></div>
      </li>
      <li class="proportion">
        <div>
          <p>发币折扣：<span>0.5</span></p>
          <p>返利比例：<span>20%</span></p>
          <p></p>
        </div>
        <div>
          <p>下级发币：<span>0.5</span></p>
          <p>下级返利：<span>20%</span></p>
          <p>优惠类型：<span>返利</span></p>
        </div>
      </li>
    </ul>
    <ul class="myGame_ul">
      <li class="myGame_ul__li">
        <div class="gameImg"><img src="../../assets/images/3.png" alt=""></div>
        <div class="gameDetail">
          <p class="gameDetail_p1">三届毒霸&nbsp;&nbsp;<img src="../../assets/images/huosdk_tg_android.png" ></p>
          <p class="gameDetail_p2">游戏ID：123123</p>
          <p class="gameDetail_p3"><span class="discounts">待出包</span></p>
        </div>
        <div class="gameBtn"><a href="javascript:;" @click="popTip('分包成功')">生成包</a></div>
      </li>
      <li class="proportion">
        <div>
          <p>发币折扣：<span>0.5</span></p>
          <p>返利比例：<span>20%</span></p>
          <p></p>
        </div>
        <div>
          <p>下级发币：<span>0.5</span></p>
          <p>下级返利：<span>20%</span></p>
          <p>优惠类型：<span>返利</span></p>
        </div>
      </li>
    </ul>
    <ul class="myGame_ul">
      <li class="myGame_ul__li">
        <div class="gameImg"><img src="../../assets/images/4.png" alt=""></div>
        <div class="gameDetail">
          <p class="gameDetail_p1">三届毒霸&nbsp;&nbsp;<img src="../../assets/images/huosdk_tg_android.png" ></p>
          <p class="gameDetail_p2">游戏ID：123123</p>
          <p class="gameDetail_p3"><span class="discounts">已出包</span></p>
        </div>
        <div class="gameBtn">
          <a class="update" href="javascript:;" @click="popTip('更新成功')">更新</a>
          <a class="storeCode" href="javascript:;" @click="storeQrcode()">保存二维码</a>
          <a class="cloneHttp" href="javascript:;" @click="popTip('复制成功')">复制推广</a>
        </div>
      </li>
      <li class="proportion">
        <div>
          <p>发币折扣：<span>0.5</span></p>
          <p>返利比例：<span>20%</span></p>
          <p></p>
        </div>
        <div>
          <p>下级发币：<span>0.5</span></p>
          <p>下级返利：<span>20%</span></p>
          <p>优惠类型：<span>返利</span></p>
        </div>
      </li>
    </ul>

  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import store from '../../store'
export default {
  components: {

  },
  computed: {
    ...mapGetters([
      'qrCodeStatus'
    ])
  },
  watch: {

  },
  data () {
    return {

    }
  },
  created () {
  },
  methods: {
    popTip (text) {
      store.commit('UPDATE_TIP_STATUS', {'tip': true, 'msg': text})
    },
    storeQrcode () {
      store.commit('UPDATE_QRCODE_STATUS', {'qrCodeStatus': true})
    }
  },
  mounted () {
    store.commit('UPDATE_SELECT_NUM', {'num': 1})
  }
}
</script>

<style lang="scss" scoped>
.myGame{
  .myGame_ul{
    margin-bottom: 0.16rem;
    background-color: #fff;
    &__li{
      padding: 0.35rem 0.3rem;
      display: flex;
      border-bottom: 1px solid #EEEEEE;
    }
  }
}
.gameImg{
  width: 1.62rem;
  height: 1.3rem;
  padding-right: 0.32rem;
  img{
    width: 1.3rem;
    height: 1.3rem;
  }
}
.gameDetail{
  flex: 1;
  &_p1{
    font-size:0.32rem;
    color: #333;
    img{
      width: 0.26rem;
      height: 0.3rem;
      vertical-align: middle;
    }
    span{
      font-size: 0.24rem;
      color:#FF3636;
    }
  }
  &_p2{
    font-size: 0.24rem;
    color: #777777;
    padding-top: 0.1rem;
  }
  &_p3{
    font-size: 0.24rem;
    color: #777777;
    padding-top: 0.1rem;
    .discounts{
      color:#FF3636;
    }
  }
}
.gameBtn{
  width: 2.8rem;
  position: relative;
  a{
    position: absolute;
    right: 0;
    top: 50%;
    transform: translateY(-50%);
    display: flex;
    align-items: center;
    justify-content: center;
    width: 1.1rem;
    height: 0.6rem;
    color: #fff;
    text-align: center;
    font-size: 0.26rem;
    background-color: #67C23A;
    border-radius: 0.05rem;
  }
  .update{
    background-color: #409FFF;
    top:0;
    right: 0;
    top: auto;
    transform: translateY(0);
  }
  .storeCode, .cloneHttp{
    display: block;
    height: 0.54rem;
    line-height: 0.54rem;
    font-size: 0.22rem;
    color: #777;
    border: 1px solid #EEEEEE;
    background-color: #F7F7F7;
    position: absolute;
    top: auto;
    transform: translateY(0);
  }
  .storeCode{
    bottom: 0;
    left:0;
    width: 1.4rem;
  }
  .cloneHttp{
    right: 0;
    bottom: 0;
    width: 1.2rem;
  }
}
.proportion{
  padding: 0.26rem 0.3rem;
  div{
    display: flex;
    p{
      flex: 1;
      font-size: 0.24rem;
      color: #99A9BF;
      span{
        color: #333;
      }
    }
  }
  div:nth-child(2){
    padding-top: 0.3rem;
  }
}
</style>
