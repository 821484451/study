<template>
  <div class="gameList">
    <ul class="gameList_ul">
      <li class="gameList_ul__li">
        <div class="gameImg"><img src="../../assets/images/1.png" alt=""></div>
        <div class="gameDetail">
          <p class="gameDetail_p1">三届毒霸&nbsp;&nbsp;<img src="../../assets/images/huosdk_tg_ios.png" > <span class="checking">需审核</span></p>
          <p class="gameDetail_p2">游戏ID：123123</p>
          <p class="gameDetail_p3">折扣：<span class="discounts">5折</span>&nbsp;&nbsp;&nbsp;&nbsp;<span class="returnMoney">玩家优惠：返利</span></p>
        </div>
        <div class="gameBtn"><a href="javascript:;" @click="popAdd('三届毒霸')">申请</a></div>
      </li>
      <li class="gameList_ul__li">
        <div class="gameImg"><img src="../../assets/images/2.png" alt=""></div>
        <div class="gameDetail">
          <p class="gameDetail_p1">三届毒霸&nbsp;&nbsp;<img src="../../assets/images/huosdk_tg_ios.png" > <span class="checking">需审核</span></p>
          <p class="gameDetail_p2">游戏ID：123123</p>
          <p class="gameDetail_p3">折扣：<span class="discounts">5折</span>&nbsp;&nbsp;&nbsp;&nbsp;<span class="returnMoney">玩家优惠：返利</span></p>
        </div>
        <div class="gameBtn"><a href="javascript:;" @click="popAdd('三届毒霸')">申请</a></div>
      </li>
      <li class="gameList_ul__li">
        <div class="gameImg"><img src="../../assets/images/3.png" alt=""></div>
        <div class="gameDetail">
          <p class="gameDetail_p1">三届毒霸&nbsp;&nbsp;<img src="../../assets/images/huosdk_tg_ios.png" > <span class="checking">需审核</span></p>
          <p class="gameDetail_p2">游戏ID：123123</p>
          <p class="gameDetail_p3">折扣：<span class="discounts">5折</span>&nbsp;&nbsp;&nbsp;&nbsp;<span class="returnMoney">玩家优惠：返利</span></p>
        </div>
        <div class="gameBtn"><a href="javascript:;" @click="popAdd('三届毒霸')">申请</a></div>
      </li>
      <li class="gameList_ul__li">
        <div class="gameImg"><img src="../../assets/images/4.png" alt=""></div>
        <div class="gameDetail">
          <p class="gameDetail_p1">三届毒霸&nbsp;&nbsp;<img src="../../assets/images/huosdk_tg_ios.png" > <span class="checking">需审核</span></p>
          <p class="gameDetail_p2">游戏ID：123123</p>
          <p class="gameDetail_p3">折扣：<span class="discounts">5折</span>&nbsp;&nbsp;&nbsp;&nbsp;<span class="returnMoney">玩家优惠：返利</span></p>
        </div>
        <div class="gameBtn"><a href="javascript:;" @click="popAdd('三届毒霸')">申请</a></div>
      </li>
      <li class="gameList_ul__li">
        <div class="gameImg"><img src="../../assets/images/1.png" alt=""></div>
        <div class="gameDetail">
          <p class="gameDetail_p1">三届毒霸&nbsp;&nbsp;<img src="../../assets/images/huosdk_tg_ios.png" > <span class="checking">需审核</span></p>
          <p class="gameDetail_p2">游戏ID：123123</p>
          <p class="gameDetail_p3">折扣：<span class="discounts">5折</span>&nbsp;&nbsp;&nbsp;&nbsp;<span class="returnMoney">玩家优惠：返利</span></p>
        </div>
        <div class="gameBtn"><a href="javascript:;" @click="popAdd('三届毒霸')">申请</a></div>
      </li>
    </ul>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import store from '../../store'
export default {
  components: {

  },
  computed: {
    ...mapGetters([
      'addText',
      'popAddStatus'
    ])
  },
  watch: {

  },
  data () {
    return {

    }
  },
  created () {

  },
  methods: {
    popAdd (text) {
      if (this.popAddStatus) {
        store.commit('UPDATE_ADD_STATUS', {'popAddStatus': false, 'addText': ''})
      } else {
        store.commit('UPDATE_ADD_STATUS', {'popAddStatus': true, 'addText': text})
      }
    }
  },
  mounted () {
    store.commit('UPDATE_SELECT_NUM', {'num': 0})
  }
}
</script>

<style lang="scss" scoped>
.gameList{
  background-color: #fff;
  .gameList_ul{
    &__li{
      padding: 0.35rem 0.3rem;
      display: flex;
      border-bottom: 1px solid #EEEEEE;
    }
  }
}
.gameImg{
  width: 1.62rem;
  height: 1.3rem;
  padding-right: 0.32rem;
  img{
    width: 1.3rem;
    height: 1.3rem;
  }
}
.gameDetail{
  flex: 1;
  &_p1{
    font-size:0.32rem;
    color: #333;
    img{
      width: 0.26rem;
      height: 0.3rem;
      vertical-align: middle;
    }
    span{
      font-size: 0.24rem;
      color:#FF3636;
    }
  }
  &_p2{
    font-size: 0.24rem;
    color: #777777;
    padding-top: 0.1rem;
  }
  &_p3{
    font-size: 0.24rem;
    color: #777777;
    padding-top: 0.1rem;
    .discounts{
      color:#FF3636;
    }
  }
}
.gameBtn{
  width: 1.7rem;
  height: 1.3rem;
  position: relative;
  a{
    position: absolute;
    top: 50%;
    right: 0;
    margin-top: -0.3rem;
    display: flex;
    width: 1.1rem;
    height: 0.6rem;
    color: #fff;
    align-items: center;
    justify-content: center;
    font-size: 0.26rem;
    background-color: #67C23A;
    border-radius: 0.05rem;
  }
}

</style>
