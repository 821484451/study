<template>
    <div class="reg">
      我是注册页面
      <router-link to="login">跳转至登录页面</router-link>
    </div>
</template>

<script>
export default {
  components: {

  },
  computed: {

  },
  watch: {

  },
  data () {
    return {

    }
  },
  created () {
  },
  methods: {

  }
}
</script>

<style lang="scss">
</style>
