<template>
  <div class="chargeList">
    <Search :channelStatus="channelStatus" :channelList="channelList" :time="time" :playerAccount="playerAccount" :orderNum="orderNum" :chargeWay="chargeWay"/>
    <div class="chargeList_head">
      <div class="chargeList_head__div1">
        <p>汇总</p>
        <p>发放数量： 1800&nbsp;&nbsp;&nbsp;支付金额：￥52441</p>
      </div>
      <div class="chargeList_head__div2">
        <img src="../../assets/images/huosdk_tg_rili.png" alt="">
      </div>
    </div>
    <ul class="chargeList_list">
      <li class="chargeList_list__li list" >
        <div class="list_div1">
          <p class="list_div1__p1">玩家001</p>
          <p class="list_div1__p2">2018-06-01 15:30</p>
        </div>
        <div class="list_div2">
          <p class="list_div2__p1">+20</p>
          <p class="list_div2__p2">充值金额</p>
          <i></i>
        </div>
        <img v-if="flag" @click="changeFlag()" src="../../assets/images/huosdk_tg_down_003.png" alt=""><img v-else @click="changeFlag()" src="../../assets/images/huosdk_tg_up_003.png" alt="">
      </li>
      <li class="detail" v-if="!flag">
        <div class="detail_div1">
          <p>渠道名称：<span>渠道003</span></p>
          <p>充值折扣：<span> 0.8折</span></p>
          <p>充值方式：<span>支付宝</span></p>
        </div>
        <div class="detail_div2">
          <p>充值游戏：<span>大圣归来</span></p>
          <p>实收金额：<span>16</span></p>
          <p>订单号：<span> 12312313213</span></p>
        </div>
      </li>
    </ul>
  </div>
</template>

<script>
import search from '../public/search.vue'
export default {
  components: {
    'Search': search
  },
  computed: {

  },
  watch: {

  },
  data () {
    return {
      flag: true,
      channelStatus: true,
      channelList: ['360', '九游', '渠道一', '渠道2', '渠道一', '渠道2', '渠道一', '渠道2'],
      time: true,
      playerAccount: true,
      orderNum: true,
      chargeWay: true
    }
  },
  created () {
  },
  methods: {
    toDetail (url) {
      this.$router.push({path: url})
    },
    changeFlag () {
      this.flag = !this.flag
    }
  }
}
</script>

<style lang="scss" scoped>
.chargeList_head{
  height: 1rem;
  padding: 0 0.3rem;
  display: flex;
  background-color: #F5F5F9;
  &__div1{
    flex: 1;
    p:nth-child(1){
      font-size: 0.28rem;
      color: #333;
      line-height: 0.5rem;
    }
    p:nth-child(2){
      font-size: 0.24rem;
      line-height: 0.5rem;
      color: #999;
    }
  }
  &__div2{
    width: 0.45rem;
    position: relative;
    img{
      width: 0.35rem;
      height: 0.34rem;
      position: absolute;
      left: 50%;
      top: 50%;
      transform: translate(-50%,-50%);
    }
  }
}
.chargeList_list{
  padding: 0 0.3rem;
  background-color: #fff;
  &__li{
    display: flex;
    justify-content: space-between;
    position: relative;
    padding-bottom: 0.43rem;
    padding-top: 0.37rem;
    img{
      width: 0.23rem;
      height: 0.12rem;
      position: absolute;
      bottom: 0.1rem;
      right: 0;
    }
  }

}
.list{
  border-bottom: 1px solid #EEEEEE;
  div{
    display: flex;
    flex-direction: column;
    justify-content: center;
  }
  &_div1{
    &__p1{
      font-size: 0.3rem;
      color: #000;
    }
    &__p2{
      font-size: 0.24rem;
      color: #7C7C7C;
      padding-top: 0.23rem;
    }
  }
  &_div2{
    position: relative;
    &__p1{
      font-size: 0.56rem;
      color: #FF3D59;
      font-weight: bold;
    }
    &__p2{
      font-size: 0.24rem;
      color: #888;
    }
    i{
      width: 1px;
      height: 0.5rem;
      background-color: #EEE;
      position: absolute;
      left: -0.5rem;
      top: 50%;
      margin-top: -0.25rem;

    }
  }
}
.detail{
  padding: 0 0.3rem;
  display: flex;
  div{
    color: #99A9BF;
    font-size: 0.24rem;
    P:nth-child(1){
      padding-top: 0.26rem;
    }
    P:nth-child(2){
      padding-top: 0.3rem;
    }
    P:nth-child(3){
      padding-top: 0.31rem;
      padding-bottom: 0.24rem;
    }
    span{
      color: #555555;
    }
  }
  &_div1{
    width: 2.74rem;
  }
  &_div2{
    flex: 1;
  }
}
</style>
