<template>
  <div style="width: 100%;overflow-y: hidden;">
    <div id="myChart" :style="{width: '1000px', height: '300px'}"></div>
  </div>
</template>

<script>
import 'zrender/lib/svg/svg'
import { mapGetters } from 'vuex'
export default {
  name: 'hello',
  data () {
    return {
      msg: ''
    }
  },
  created () {

  },
  props: [

  ],
  watch: {
    commonTimeList (curVal, oldVal) {
      this.drawLine()
    }
  },
  computed: {
    ...mapGetters([
      'commonTimeList',
      'detail'
    ])
  },
  mounted () {
    this.drawLine()
  },
  methods: {
    drawLine () {
      const self = this
      let myChart = this.$echarts.init(document.getElementById('myChart'), null, {renderer: 'svg'})
      // 绘制图表
      myChart.setOption({
        title: {
          text: ''
        },
        tooltip: {
          trigger: 'axis'
        },
        legend: {
          data: []
        },
        grid: {
          left: '2%',
          top: '3%',
          right: '2%',
          bottom: '2%',
          containLabel: true
        },
        toolbox: {
          feature: {

          }
        },
        xAxis: {
          type: 'category',
          boundaryGap: false,
          data: self.commonTimeList,
          axisLabel: {
            interval: 0
          }
        },
        yAxis: {
          type: 'value'
        },
        series: [
          {
            name: '流水',
            type: 'line',
            stack: '总量',
            data: self.detail
          }
        ]
      })
    }
  }
}
</script>

<style lang="scss">
</style>
