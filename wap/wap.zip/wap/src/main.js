// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import 'babel-polyfill'
import Vue from 'vue'
import App from './App'
import router from './router'
import store from './store'
import './assets/js/rem'
// import './assets/js/vconsole'
var echarts = require('echarts')
Vue.config.productionTip = false
Vue.prototype.$echarts = echarts
Vue.prototype.$scroll = {
  stop () {
    document.body.style.overflow = 'hidden'
    var home = document.getElementsByClassName('home')[0]
    home.style.overflow = 'hidden'
    home.style.height = '100%'
  },
  move () {
    document.body.style.overflow = ''
    var home = document.getElementsByClassName('home')[0]
    home.style.overflow = ''
    home.style.height = 'auto'
  }
}
/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  store,
  components: { App },
  template: '<App/>'
})
